# todo: write to a text file

file_out = open('writefile.txt', 'w')
file_out.write('This is a test\n')
file_out.write('And a second line in the file')

file_out.close()