starting_list = [1, 45, -76, 23, 5, 12, 4, 7, 9, 12, 12, -4, -67, -66, 89, -101]
# todo: create a list of all the even numbers in starting_list


# todo: create a list of all the numbers less than zero multiplied by 3


# todo: all numbers between 0 and 100 that are divisible by BOTH 3 and 7


# todo: create a list of all the odd numbers greater than 0 from starting_list


# todo: a list of all numbers less than 100. If the number is even add 'even' to the list, otherwise add 'odd' to the list
