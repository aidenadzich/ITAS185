start = [1, 3, 4, 7, 9 , 18]

# todo: loop to create a new array called 'end' with the squares of each of the elements of 'start'


# todo: Now do the same with a comprehension


# todo: produce a list of the cubes (exponent 3) of all numbers from 3 to 15 inclusive


# todo: a list of every second number from 1 to 100 inclusive
