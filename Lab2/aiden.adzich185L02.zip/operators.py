"""
Aiden Adzich
ITAS Lab #2, Part #E
This program does a bunch of operations and prints after each one

"""

total = 0
print(f"The total is {total}")
total += 96
print(f"The total is {total}")
total -= 8
print(f"The total is {total}")
total //= 3
print(f"The total is {total}")
total %= 5
print(f"The total is {total}")
total **= 3
print(f"The total is {total}")
total /= 8
print(f"The total is {total}")
total *= 7
print(f"The total is {total}")